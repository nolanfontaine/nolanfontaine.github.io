setwd("C:/Users/nfonta06/OneDrive - Université de Poitiers/S2/SAE/STAT")

train <- read.csv2("train.csv")
test <- read.csv2("test.csv")

############# Modèle Maison (linéaire) #############

# Filtrer pour ne garder que les maisons
train_maisons <- subset(train, Type.local == "Maison")
test_maisons <- subset(test, Type.local == "Maison")

# Calculer le prix moyen au m² par commune
prix_m2_commune_maisons <- aggregate(Valeur.fonciere / Surface.reelle.bati ~ Commune, data = train_maisons, FUN = function(x) {
  model <- lm(x ~ 1)
  coef(model)[1]
})
names(prix_m2_commune_maisons) <- c("Commune", "prix_m2_moyen")

# Fusionner avec le fichier test
predictions_maisons <- merge(test_maisons, prix_m2_commune_maisons, by = "Commune", all.x = TRUE)

# Calculer la valeur prédite pour chaque maison
predictions_maisons$valeur_predite <- predictions_maisons$prix_m2_moyen * predictions_maisons$Surface.reelle.bati

# Modèle linéaire global (toutes les maisons)
modele_global_maisons <- lm(Valeur.fonciere ~ Surface.reelle.bati, data = train_maisons)
A_global_maisons <- coef(modele_global_maisons)[1]
B_global_maisons <- coef(modele_global_maisons)[2]

# Appliquer le modèle global si NA
predictions_maisons$valeur_predite <- ifelse(
  is.na(predictions_maisons$valeur_predite),
  A_global_maisons + B_global_maisons * predictions_maisons$Surface.reelle.bati,
  predictions_maisons$valeur_predite
)

# Date et année
predictions_maisons$Date.mutation <- as.Date(predictions_maisons$Date.mutation, format = "%d/%m/%Y")
predictions_maisons$annee_mutation <- format(predictions_maisons$Date.mutation, "%Y")

# Taux d'évolution 2023 → 2024
valeurs_2023_maisons <- subset(train_maisons, format(as.Date(Date.mutation, format = "%d/%m/%Y"), "%Y") == "2023")
valeurs_2024_maisons <- subset(train_maisons, format(as.Date(Date.mutation, format = "%d/%m/%Y"), "%Y") == "2024")

moyenne_2023_maisons <- mean(valeurs_2023_maisons$Valeur.fonciere, na.rm = TRUE)
moyenne_2024_maisons <- mean(valeurs_2024_maisons$Valeur.fonciere, na.rm = TRUE)

taux_evolution_maisons <- ifelse(!is.na(moyenne_2023_maisons) & !is.na(moyenne_2024_maisons) & moyenne_2023_maisons != 0, 
                                 moyenne_2024_maisons / moyenne_2023_maisons, 1)

# Appliquer le taux
predictions_maisons$valeur_predite <- ifelse(predictions_maisons$annee_mutation == "2024", 
                                             predictions_maisons$valeur_predite * taux_evolution_maisons, 
                                             predictions_maisons$valeur_predite)


############# Modèle Appartement (linéaire) #############

train_appartements <- subset(train, Type.local == "Appartement")
test_appartements <- subset(test, Type.local == "Appartement")

# Prix moyen m² par commune + nb pièces
prix_m2_commune_pieces <- aggregate(Valeur.fonciere / Surface.reelle.bati ~ Commune + Nombre.pieces.principales, 
                                    data = train_appartements, FUN = function(x) {
                                      model <- lm(x ~ 1)
                                      coef(model)[1]
                                    })
names(prix_m2_commune_pieces) <- c("Commune", "Nombre.pieces.principales", "prix_m2_moyen")

# Fusion principale
predictions_appartements <- merge(test_appartements, prix_m2_commune_pieces, by = c("Commune", "Nombre.pieces.principales"), all.x = TRUE)

# Fallback : prix moyen m² par commune seule
prix_m2_commune <- aggregate(Valeur.fonciere / Surface.reelle.bati ~ Commune, 
                             data = train_appartements, FUN = mean, na.rm = TRUE)
names(prix_m2_commune) <- c("Commune", "prix_m2_moyen_fallback")

# Fusion fallback
predictions_appartements <- merge(predictions_appartements, prix_m2_commune, by = "Commune", all.x = TRUE)

# Sélection de la meilleure valeur dispo
predictions_appartements$prix_m2_final <- ifelse(!is.na(predictions_appartements$prix_m2_moyen),
                                                 predictions_appartements$prix_m2_moyen,
                                                 predictions_appartements$prix_m2_moyen_fallback)

# Modèle global pour appartements
modele_global_appartements <- lm(Valeur.fonciere ~ Surface.reelle.bati, data = train_appartements)
A_global_appartements <- coef(modele_global_appartements)[1]
B_global_appartements <- coef(modele_global_appartements)[2]

# Valeur prédite selon la meilleure méthode
predictions_appartements$valeur_predite <- ifelse(
  !is.na(predictions_appartements$prix_m2_final),
  predictions_appartements$prix_m2_final * predictions_appartements$Surface.reelle.bati,
  A_global_appartements + B_global_appartements * predictions_appartements$Surface.reelle.bati
)

# Nettoyage
predictions_appartements$prix_m2_moyen <- NULL
predictions_appartements$prix_m2_moyen_fallback <- NULL
predictions_appartements$prix_m2_final <- NULL

# Date et année
predictions_appartements$Date.mutation <- as.Date(predictions_appartements$Date.mutation, format = "%d/%m/%Y")
predictions_appartements$annee_mutation <- format(predictions_appartements$Date.mutation, "%Y")

# Taux d'évolution 2023 → 2024
valeurs_2023_appartements <- subset(train_appartements, format(as.Date(Date.mutation, format = "%d/%m/%Y"), "%Y") == "2023")
valeurs_2024_appartements <- subset(train_appartements, format(as.Date(Date.mutation, format = "%d/%m/%Y"), "%Y") == "2024")

moyenne_2023_appartements <- mean(valeurs_2023_appartements$Valeur.fonciere, na.rm = TRUE)
moyenne_2024_appartements <- mean(valeurs_2024_appartements$Valeur.fonciere, na.rm = TRUE)

taux_evolution_appartements <- ifelse(!is.na(moyenne_2023_appartements) & !is.na(moyenne_2024_appartements) & moyenne_2023_appartements != 0, 
                                      moyenne_2024_appartements / moyenne_2023_appartements, 1)

# Appliquer le taux
predictions_appartements$valeur_predite <- ifelse(predictions_appartements$annee_mutation == "2024", 
                                                  predictions_appartements$valeur_predite * taux_evolution_appartements, 
                                                  predictions_appartements$valeur_predite)


############# Combiner les résultats #############

predictions_maisons$Type.local <- "Maison"
predictions_appartements$Type.local <- "Appartement"

predictions_final <- rbind(predictions_maisons[, c("id", "valeur_predite")], 
                           predictions_appartements[, c("id", "valeur_predite")])

# Réorganiser selon test
predictions_final <- predictions_final[match(test$id, predictions_final$id), ]

# Renommer et exporter
names(predictions_final)[names(predictions_final) == "valeur_predite"] <- "Valeur.fonciere"
write.csv2(predictions_final, "prediction.csv", row.names = FALSE)