-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 24 mars 2025 à 10:40
-- Version du serveur :  5.7.17
-- Version de PHP :  5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `sauniernoanolan`
--

-- --------------------------------------------------------

--
-- Structure de la table `anneeprix`
--

CREATE TABLE `anneeprix` (
  `Annee` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `anneeprix`
--

INSERT INTO `anneeprix` (`Annee`) VALUES
(2023),
(2024),
(2025),
(2026),
(2027),
(2028),
(2029),
(2030);

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `numCli` int(11) NOT NULL,
  `nomCli` varchar(50) NOT NULL,
  `precisionCli` varchar(50) NOT NULL,
  `villeCli` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`numCli`, `nomCli`, `precisionCli`, `villeCli`) VALUES
(1, 'CAVANA', 'Marie', 'LA ROCHELLE'),
(2, 'BURLET', 'Michel', 'LAGORD'),
(3, 'PEUTOT', 'Maurice', 'LAGORD'),
(4, 'ORGEVAL', 'Centrale d’Achats', 'SURGERES'),
(5, 'SICAAP', 'Centrale d\'Achats', 'FONTCOUVERTE'),
(6, 'GIE DE L\'AUNIS', 'Centrale d\'Achats', 'VOUHE'),
(7, 'EVEILLE', 'Johann', 'LA ROCHELLE'),
(8, 'BARBOTTIN', 'Olivier', 'MEURSAC'),
(9, 'UNION DES PRODUCTEURS DE LA MER', 'Centrale d\'Achats', 'RIVEDOUX'),
(10, 'LIDL', 'Centrale d\'Achats', 'PUILBOREAU'),
(11, 'CARREFOUR', 'Centrale d\'Achats', 'LA ROCHELLE');

-- --------------------------------------------------------

--
-- Structure de la table `concerner`
--

CREATE TABLE `concerner` (
  `numPdt` int(11) NOT NULL,
  `numSort` int(11) NOT NULL,
  `qteSort` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `concerner`
--

INSERT INTO `concerner` (`numPdt`, `numSort`, `qteSort`) VALUES
(1, 20231, 500),
(1, 20234, 250),
(1, 20235, 150),
(1, 20237, 500),
(1, 20241, 300),
(1, 20242, 200),
(1, 20243, 100),
(1, 202310, 700),
(1, 202311, 200),
(1, 202313, 500),
(1, 202315, 100),
(1, 202316, 350),
(1, 202318, 100),
(1, 202319, 300),
(1, 202320, 400),
(1, 202322, 200),
(1, 202323, 400),
(1, 202324, 150),
(1, 202325, 300),
(1, 202327, 600),
(1, 202328, 400),
(1, 202329, 300),
(1, 202330, 100),
(1, 202331, 500),
(1, 202332, 200),
(1, 202333, 200),
(1, 202335, 200),
(1, 202337, 300),
(1, 202339, 200),
(1, 202340, 300),
(1, 202341, 200),
(1, 202342, 650),
(1, 202344, 500),
(1, 202345, 300),
(1, 202347, 100),
(1, 202348, 700),
(1, 202349, 300),
(1, 202351, 300),
(1, 202352, 400),
(1, 202354, 300),
(1, 202355, 400),
(1, 202357, 200),
(1, 202358, 300),
(1, 202359, 400),
(1, 202360, 200),
(2, 20231, 500),
(2, 20232, 200),
(2, 20233, 300),
(2, 20234, 200),
(2, 20236, 100),
(2, 20237, 500),
(2, 20238, 200),
(2, 20239, 200),
(2, 20241, 400),
(2, 20243, 500),
(2, 202310, 450),
(2, 202312, 200),
(2, 202314, 100),
(2, 202316, 400),
(2, 202317, 500),
(2, 202320, 300),
(2, 202321, 400),
(2, 202325, 300),
(2, 202326, 300),
(2, 202328, 500),
(2, 202331, 500),
(2, 202334, 1000),
(2, 202336, 200),
(2, 202337, 600),
(2, 202338, 200),
(2, 202343, 400),
(2, 202344, 200),
(2, 202346, 100),
(2, 202348, 1000),
(2, 202350, 300),
(2, 202353, 700),
(2, 202356, 400),
(2, 202358, 300),
(2, 202359, 400),
(2, 202361, 300);

-- --------------------------------------------------------

--
-- Structure de la table `entree`
--

CREATE TABLE `entree` (
  `numEnt` int(11) NOT NULL,
  `dateEnt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `qteEnt` int(11) NOT NULL,
  `numPdt` int(11) NOT NULL,
  `numSau` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entree`
--

INSERT INTO `entree` (`numEnt`, `dateEnt`, `qteEnt`, `numPdt`, `numSau`) VALUES
(20231, '2024-01-04 00:00:00', 2000, 1, 1),
(20232, '2024-01-04 00:00:00', 3000, 2, 1),
(20233, '2024-01-09 00:00:00', 2000, 1, 4),
(20234, '2024-01-09 00:00:00', 2000, 2, 4),
(20235, '2024-02-02 00:00:00', 4000, 1, 3),
(20236, '2024-02-05 00:00:00', 3000, 2, 2),
(20237, '2024-03-01 00:00:00', 1000, 1, 4),
(20238, '2024-03-01 00:00:00', 4000, 2, 4),
(20239, '2024-05-07 00:00:00', 3000, 1, 1),
(20241, '2024-06-16 00:00:00', 1000, 1, 1),
(20242, '2024-06-18 00:00:00', 500, 1, 2),
(20243, '2024-07-10 00:00:00', 1500, 2, 2),
(202310, '2024-06-08 00:00:00', 3000, 1, 1),
(202311, '2024-06-08 00:00:00', 3000, 2, 1),
(202312, '2024-06-29 00:00:00', 2000, 1, 3),
(202313, '2024-07-01 00:00:00', 1000, 2, 2),
(202314, '2024-08-07 00:00:00', 3000, 1, 4),
(202315, '2024-08-07 00:00:00', 2000, 2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `prix`
--

CREATE TABLE `prix` (
  `numPdt` int(11) NOT NULL,
  `Annee` int(11) NOT NULL,
  `PrixAchat` int(11) NOT NULL,
  `PrixVente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `prix`
--

INSERT INTO `prix` (`numPdt`, `Annee`, `PrixAchat`, `PrixVente`) VALUES
(1, 2023, 270, 280),
(1, 2024, 270, 290),
(1, 2025, 240, 300),
(2, 2023, 3900, 9500),
(2, 2024, 3800, 10000),
(2, 2025, 3500, 9000);

-- --------------------------------------------------------

--
-- Structure de la table `produit`
--

CREATE TABLE `produit` (
  `numPdt` int(11) NOT NULL,
  `libPdt` varchar(50) NOT NULL,
  `stockPdt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `produit`
--

INSERT INTO `produit` (`numPdt`, `libPdt`, `stockPdt`) VALUES
(1, 'Gros sel', 2000),
(2, 'Fleur de sel', 1000);

-- --------------------------------------------------------

--
-- Structure de la table `saunier`
--

CREATE TABLE `saunier` (
  `numSau` int(11) NOT NULL,
  `nomSau` varchar(50) NOT NULL,
  `prenomSau` varchar(50) NOT NULL,
  `villeSau` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `saunier`
--

INSERT INTO `saunier` (`numSau`, `nomSau`, `prenomSau`, `villeSau`) VALUES
(1, 'YVAN', 'Pierre', 'Ars-En-Ré'),
(2, 'PETIT', 'Marc', 'Loix'),
(3, 'CARBRAC', 'Léonie', 'Rivedoux'),
(4, 'TARDIVEL', 'Thierry', 'La Couarde');

-- --------------------------------------------------------

--
-- Structure de la table `sortie`
--

CREATE TABLE `sortie` (
  `numSort` int(11) NOT NULL,
  `dateSort` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `numCli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sortie`
--

INSERT INTO `sortie` (`numSort`, `dateSort`, `numCli`) VALUES
(20231, '2024-01-05 00:00:00', 10),
(20232, '2024-01-06 00:00:00', 2),
(20233, '2024-01-06 00:00:00', 5),
(20234, '2024-01-06 00:00:00', 11),
(20235, '2024-01-09 00:00:00', 2),
(20236, '2024-01-09 00:00:00', 3),
(20237, '2024-01-12 00:00:00', 11),
(20238, '2024-01-12 00:00:00', 6),
(20239, '2024-01-23 00:00:00', 1),
(20241, '2024-07-16 00:00:00', 1),
(20242, '2024-07-18 00:00:00', 1),
(20243, '2024-08-10 00:00:00', 2),
(202310, '2024-02-14 00:00:00', 10),
(202311, '2024-02-14 00:00:00', 3),
(202312, '2024-02-16 00:00:00', 10),
(202313, '2024-02-28 00:00:00', 9),
(202314, '2024-03-08 00:00:00', 1),
(202315, '2024-03-09 00:00:00', 2),
(202316, '2024-03-10 00:00:00', 10),
(202317, '2024-03-19 00:00:00', 7),
(202318, '2024-03-22 00:00:00', 1),
(202319, '2024-03-23 00:00:00', 10),
(202320, '2024-03-23 00:00:00', 10),
(202321, '2024-04-04 00:00:00', 11),
(202322, '2024-04-06 00:00:00', 11),
(202323, '2024-04-17 00:00:00', 10),
(202324, '2024-04-20 00:00:00', 1),
(202325, '2024-04-29 00:00:00', 11),
(202326, '2024-05-02 00:00:00', 3),
(202327, '2024-05-04 00:00:00', 7),
(202328, '2024-05-22 00:00:00', 11),
(202329, '2024-06-03 00:00:00', 10),
(202330, '2024-06-03 00:00:00', 1),
(202331, '2024-06-04 00:00:00', 11),
(202332, '2024-06-05 00:00:00', 6),
(202333, '2024-06-06 00:00:00', 7),
(202334, '2024-06-07 00:00:00', 8),
(202335, '2024-06-09 00:00:00', 2),
(202336, '2024-06-30 00:00:00', 5),
(202337, '2024-07-01 00:00:00', 10),
(202338, '2024-07-01 00:00:00', 9),
(202339, '2024-07-02 00:00:00', 11),
(202340, '2024-07-13 00:00:00', 5),
(202341, '2024-07-24 00:00:00', 7),
(202342, '2024-08-05 00:00:00', 10),
(202343, '2024-08-06 00:00:00', 10),
(202344, '2024-08-06 00:00:00', 11),
(202345, '2024-09-02 00:00:00', 5),
(202346, '2024-09-08 00:00:00', 1),
(202347, '2024-09-19 00:00:00', 7),
(202348, '2024-10-10 00:00:00', 11),
(202349, '2024-10-11 00:00:00', 4),
(202350, '2024-11-02 00:00:00', 9),
(202351, '2024-11-13 00:00:00', 11),
(202352, '2024-11-14 00:00:00', 10),
(202353, '2024-11-15 00:00:00', 10),
(202354, '2024-11-15 00:00:00', 4),
(202355, '2024-11-15 00:00:00', 6),
(202356, '2024-12-08 00:00:00', 11),
(202357, '2024-12-11 00:00:00', 4),
(202358, '2024-12-20 00:00:00', 10),
(202359, '2024-12-21 00:00:00', 11),
(202360, '2024-12-22 00:00:00', 6),
(202361, '2024-12-23 00:00:00', 2);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `anneeprix`
--
ALTER TABLE `anneeprix`
  ADD PRIMARY KEY (`Annee`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`numCli`),
  ADD UNIQUE KEY `nomCli` (`nomCli`,`villeCli`);

--
-- Index pour la table `concerner`
--
ALTER TABLE `concerner`
  ADD PRIMARY KEY (`numPdt`,`numSort`),
  ADD KEY `numSort` (`numSort`);

--
-- Index pour la table `entree`
--
ALTER TABLE `entree`
  ADD PRIMARY KEY (`numEnt`),
  ADD KEY `numPdt` (`numPdt`),
  ADD KEY `numSau` (`numSau`);

--
-- Index pour la table `prix`
--
ALTER TABLE `prix`
  ADD PRIMARY KEY (`numPdt`,`Annee`),
  ADD KEY `Annee` (`Annee`);

--
-- Index pour la table `produit`
--
ALTER TABLE `produit`
  ADD PRIMARY KEY (`numPdt`),
  ADD UNIQUE KEY `libPdt` (`libPdt`);

--
-- Index pour la table `saunier`
--
ALTER TABLE `saunier`
  ADD PRIMARY KEY (`numSau`);

--
-- Index pour la table `sortie`
--
ALTER TABLE `sortie`
  ADD PRIMARY KEY (`numSort`),
  ADD KEY `numCli` (`numCli`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `concerner`
--
ALTER TABLE `concerner`
  ADD CONSTRAINT `concerner_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`),
  ADD CONSTRAINT `concerner_ibfk_2` FOREIGN KEY (`numSort`) REFERENCES `sortie` (`numSort`);

--
-- Contraintes pour la table `entree`
--
ALTER TABLE `entree`
  ADD CONSTRAINT `entree_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`),
  ADD CONSTRAINT `entree_ibfk_2` FOREIGN KEY (`numSau`) REFERENCES `saunier` (`numSau`);

--
-- Contraintes pour la table `prix`
--
ALTER TABLE `prix`
  ADD CONSTRAINT `prix_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`),
  ADD CONSTRAINT `prix_ibfk_2` FOREIGN KEY (`Annee`) REFERENCES `anneeprix` (`Annee`);

--
-- Contraintes pour la table `sortie`
--
ALTER TABLE `sortie`
  ADD CONSTRAINT `sortie_ibfk_1` FOREIGN KEY (`numCli`) REFERENCES `client` (`numCli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
