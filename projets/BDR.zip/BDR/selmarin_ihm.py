import mysql.connector
import ttkbootstrap as tb 
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import os
from selmarin import traiter_csv
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def connect_db():
    """ Établit la connexion à la base de données et retourne le curseur. """
    params = {"host": "localhost", "user": "root", "password": "", "database": "selmarinnolannoa"}
    db = mysql.connector.connect(**params)
    return db, db.cursor()

def masquer_tables(frame_tables, btn_afficher, btn_masquer):
    """ Masque les tables affichées. """
    for widget in frame_tables.winfo_children():
        widget.grid_forget()
    btn_masquer.grid_forget()
    btn_afficher.grid(row=0, column=0, padx=5)

def afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role):
    """ Affiche les tables de la base de données dans l'interface avec un affichage dynamique."""
    # Effacer les widgets précédents
    for widget in frame_tables.winfo_children():
        widget.destroy()

    cursor.execute("SHOW TABLES")
    tables = [table[0] for table in cursor.fetchall()]

    row = 1  # Définir une valeur par défaut pour row

    if tables:
        btn_afficher.grid_forget()
        btn_masquer.grid(row=0, column=0, padx=5)
    
        for table in tables:
            label = tb.Label(frame_tables, text=f"\U0001F4C2 Table : {table}", font=("Arial", 12, "bold"), bootstyle="info")
            label.grid(row=row, column=0, sticky="w", pady=25, padx=10)  # Réduction du padding vertical

            btn_voir = tb.Button(
                frame_tables, 
                text="Voir",  
                bootstyle="success-outline", 
                width=8,  
                padding=(3, 4),
                command=lambda t=table: voir_table(cursor, t, frame_tables.winfo_toplevel(), role)  # Passer la fenêtre principale
            )
            btn_voir.grid(row=row, column=1, padx=7, sticky="w")


            if role == "Administrateur":
                btn_supprimer = tb.Button(
                    frame_tables, 
                    text="Supprimer",  
                    bootstyle="danger-outline", 
                    width=9,  
                    padding=(3, 4),  # Réduction du padding
                    command=lambda t=table: supprimer_table(cursor, t, frame_tables, btn_afficher, btn_masquer, role)
                )
                btn_supprimer.grid(row=row, column=2, padx=7, sticky="w")

            row += 1  # Incrémentation pour la prochaine table

    else:
        btn_afficher.grid_forget()
        btn_masquer.grid(row=0, column=0, padx=5)
        # Affichage du message si aucune table n'est trouvée
        message_label = tb.Label(frame_tables, text="Aucune table dans la base de données", font=("Arial", 14, "bold"), bootstyle="danger")
        message_label.grid(row=0, column=0, pady=10)
        
    if role == "Administrateur":
        btn_ajouter = tb.Button(
            frame_tables,
            text="➕ Ajouter Table",
            bootstyle="success-outline",
            width=15,
            padding=(5, 6),
            command=lambda: ajouter_table(cursor, db, frame_tables, btn_afficher, btn_masquer, role, frame_tables.winfo_toplevel())
        )
        # Le bouton "Ajouter Table" doit être positionné après les tables ou le message si aucune table
        btn_ajouter.grid(row=row + 1, column=0, columnspan=3, pady=15)


def ajouter_table(cursor, db, frame_tables, btn_afficher, btn_masquer, role, parent_window):
    if parent_window:
        parent_window.withdraw()

    """ Ouvre une fenêtre popup pour ajouter une nouvelle table avec ses attributs. """
    popup = tk.Toplevel(frame_tables)
    popup.title("Ajouter une Table")
    popup.state("zoomed")

    # Création du Canvas et de la Scrollbar (ttk)
    canvas = tk.Canvas(popup)
    scrollbar = ttk.Scrollbar(popup, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    # Création du Frame à l'intérieur du Canvas
    frame_scroll = tb.Frame(canvas)

    # Ajout du Frame au Canvas
    canvas.create_window((0, 0), window=frame_scroll, anchor="nw")
    
    # Grille pour occuper toute la page
    canvas.grid(row=0, column=0, sticky="nsew")
    scrollbar.grid(row=0, column=1, sticky="ns")

    # Configuration de la grille de la fenêtre pour prendre toute la page
    popup.grid_rowconfigure(0, weight=1)
    popup.grid_columnconfigure(0, weight=1)
    popup.grid_columnconfigure(1, weight=0)

    # Mise à jour de la taille du canvas lorsque le contenu change
    frame_scroll.update_idletasks()
    canvas.config(scrollregion=canvas.bbox("all"))

    tb.Label(frame_scroll, text="Nom de la Table:", font=("Arial", 12, "bold")).grid(row=0, column=0, padx=5, pady=5, sticky="w")
    entry_nom = tb.Entry(frame_scroll, width=30)
    entry_nom.grid(row=0, column=1, padx=5, pady=5, sticky="w")

    frame_attributs = tb.Frame(frame_scroll)
    frame_attributs.grid(row=1, column=0, columnspan=2, pady=10, padx=5, sticky="w")

    attributs = []

    def ajouter_attribut():
        """ Ajoute un champ pour un nouvel attribut """
        row = len(attributs)
        label = tb.Label(frame_attributs, text=f"Attribut {row+1} :", font=("Arial", 10))
        label.grid(row=row, column=0, padx=5, pady=3, sticky="w")

        entry_attr = tb.Entry(frame_attributs, width=15)
        entry_attr.grid(row=row, column=1, padx=5, pady=3)

        type_attr = tb.Combobox(frame_attributs, values=["INT", "VARCHAR(255)", "TEXT", "DATE", "FLOAT"], width=12)
        type_attr.grid(row=row, column=2, padx=5, pady=3)
        type_attr.current(0)

        attributs.append((entry_attr, type_attr))

        # Mise à jour de la région scrollable après chaque ajout
        frame_scroll.update_idletasks()
        canvas.config(scrollregion=canvas.bbox("all"))

    btn_add_attr = tb.Button(frame_scroll, text="➕ Ajouter un attribut", bootstyle="info-outline", command=ajouter_attribut)
    btn_add_attr.grid(row=2, column=0, columnspan=2, pady=5, sticky="w")

    def valider():
        """ Génère la requête SQL et ajoute la table à la base de données """
        nom_table = entry_nom.get().strip()
        if not nom_table:
            messagebox.showerror("Erreur", "Veuillez entrer un nom de table.")
            return

        colonnes = []
        for entry, combo in attributs:
            nom_attr = entry.get().strip()
            type_attr = combo.get()
            if nom_attr:
                colonnes.append(f"{nom_attr} {type_attr}")

        if not colonnes:
            messagebox.showerror("Erreur", "Ajoutez au moins un attribut.")
            return

        sql_query = f"CREATE TABLE {nom_table} ({', '.join(colonnes)});"

        try:
            cursor.execute(sql_query)
            db.commit()  # Utilisez la connexion directement pour effectuer le commit
            messagebox.showinfo("Succès", f"Table '{nom_table}' créée avec succès!")
            [popup.destroy(), parent_window.deiconify(), parent_window.state("zoomed")]
            afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role)  # Rafraîchir l'affichage
        except mysql.connector.Error as err:
            messagebox.showerror("Erreur SQL", f"Erreur lors de la création : {err}")

    btn_valider = tb.Button(frame_scroll, text="✅ Valider", bootstyle="success-outline", command=valider)
    btn_valider.grid(row=3, column=0, columnspan=2, pady=10, sticky="w")

    btn_annuler = tb.Button(frame_scroll, text="❌ Annuler", bootstyle="danger-outline", 
                            command=lambda: [popup.destroy(), parent_window.deiconify(), parent_window.state("zoomed")])
    btn_annuler.grid(row=4, column=0, columnspan=2, pady=5, sticky="w")

    ajouter_attribut()  # Ajouter le premier attribut par défaut

    # Mise à jour de la région scrollable après ajout du premier attribut
    frame_scroll.update_idletasks()
    canvas.config(scrollregion=canvas.bbox("all"))



def supprimer_table(cursor, table, frame_tables, btn_afficher, btn_masquer, role):
    """Supprime une table ou une vue avec suppression en cascade et rafraîchit l'affichage."""
    confirmation = messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer '{table}' ?")
    
    if confirmation:
        try:
            # Vérifier si la table est une vue
            cursor.execute("SHOW FULL TABLES")
            tables = cursor.fetchall()
            is_view = any(t[0] == table and t[1] == "VIEW" for t in tables)  # Vérifier si c'est une vue

            if is_view:
                # Supprimer une vue
                cursor.execute(f"DROP VIEW IF EXISTS `{table}`")
                messagebox.showinfo("Succès", f"La vue '{table}' a été supprimée.")
            else:
                # Supprimer une table avec CASCADE
                cursor.execute("SET FOREIGN_KEY_CHECKS=0")  # Désactiver les contraintes
                cursor.execute(f"DROP TABLE IF EXISTS `{table}`")
                cursor.execute("SET FOREIGN_KEY_CHECKS=1")  # Réactiver les contraintes
                messagebox.showinfo("Succès", f"La table '{table}' a été supprimée avec succès.")

            afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role)  # Rafraîchir l'affichage

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la suppression : {e}")


def inserer_ligne(cursor, db, table_name, parent_window, role, table_window=None):
    if parent_window:
        parent_window.withdraw()
    
    """Ouvre une boîte de dialogue pour insérer une nouvelle ligne dans la table."""
    if table_window:
        table_window.destroy()  # Fermer la fenêtre voir_table si elle est ouverte
    
    insert_window = tk.Toplevel()
    insert_window.title(f"Insérer une ligne dans {table_name}")
    insert_window.state("zoomed")  
    
    # Ajouter un en-tête en bleu avec un texte en gros
    header_label = tb.Label(insert_window, text=f"Insertion dans la table {table_name}", font=("Arial", 16, "bold"), bootstyle="info")
    header_label.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="ew")

    try:
        # Récupérer les colonnes de la table
        cursor.execute(f"DESCRIBE {table_name}")
        columns = [desc[0] for desc in cursor.fetchall()]
    except Exception as e:
        tk.messagebox.showerror("Erreur", f"Erreur lors de la récupération des colonnes : {e}")
        insert_window.destroy()
        return
    
    # Créer un dictionnaire pour stocker les entrées utilisateur
    entries = {}

    try:
        # Créer les champs de saisie pour chaque colonne
        for idx, col in enumerate(columns):
            label = tk.Label(insert_window, text=col)
            label.grid(row=idx + 1, column=0, padx=10, pady=5)
            entry = tk.Entry(insert_window)
            entry.grid(row=idx + 1, column=1, padx=10, pady=5)
            entries[col] = entry
    except Exception as e:
        tk.messagebox.showerror("Erreur", f"Erreur lors de la création des champs de saisie : {e}")
        insert_window.destroy()
        return

    # Fonction pour insérer la ligne
    def ajouter_ligne():
        try:
            values = [entries[col].get() for col in columns]
            query = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({', '.join(['%s'] * len(values))})"
            cursor.execute(query, tuple(values))
            db.commit()  # Sauvegarder les changements
            insert_window.destroy()
            voir_table(cursor, table_name, parent_window, role)  # Rafraîchir l'affichage
            tk.messagebox.showinfo("Succès", "Insertion réussie !")
        except Exception as e:
            tk.messagebox.showerror("Erreur", f"Erreur lors de l'insertion : {e}")

    # Ajouter un bouton pour insérer la ligne
    try:
        btn_insert = tb.Button(insert_window, text="Insérer", bootstyle="success-outline", command=ajouter_ligne)
        btn_insert.grid(row=len(columns) + 1, column=1, padx=10, pady=10)
    except Exception as e:
        tk.messagebox.showerror("Erreur", f"Erreur lors de la création du bouton Insérer : {e}")
        insert_window.destroy()
        return

    # Ajouter un bouton pour fermer la fenêtre sans insérer
    try:
        btn_cancel = tb.Button(insert_window, text="Annuler", bootstyle="danger-outline", command=lambda: [insert_window.destroy(), voir_table(cursor, table_name, parent_window, role)])
        btn_cancel.grid(row=len(columns) + 1, column=0, padx=10, pady=10)
    except Exception as e:
        tk.messagebox.showerror("Erreur", f"Erreur lors de la création du bouton Annuler : {e}")
        insert_window.destroy()
        return


def voir_table(cursor, table_name, parent_window, role):
    """Ouvre une nouvelle fenêtre et affiche le contenu de la table sélectionnée sans utiliser Treeview."""
    if parent_window:
        parent_window.withdraw()  # Masquer la fenêtre principale (ancienne page)

    table_window = tk.Toplevel()
    table_window.title(f"Table : {table_name}")
    table_window.state("zoomed")  # La nouvelle fenêtre est en plein écran

    # Création du titre centré en haut
    title_label = tb.Label(table_window, text=f"Table : {table_name}", font=("Arial", 16, "bold"), bootstyle="info")
    title_label.pack(pady=20, anchor="center")  # Centrer le titre et ajouter un peu de padding en haut

    # Exécuter la requête pour récupérer les données de la table
    cursor.execute(f"SELECT * FROM {table_name}")
    columns = [desc[0] for desc in cursor.description]  # Récupérer les noms des colonnes
    rows = cursor.fetchall()

    if role == "Administrateur":
        # Ajouter la colonne "Actions" aux colonnes existantes
        columns.append("Actions")

    # Création du cadre pour centrer le tableau avec fond gris foncé
    frame_center = tk.Frame(table_window)  
    frame_center.pack(expand=True, fill='both') 

    # Création d'un cadre pour afficher la table avec effet de profondeur
    table_frame = tk.Frame(frame_center, bd=2, relief="solid") 
    table_frame.pack(padx=10, pady=10)

    # Ajouter une ombre pour l'effet de profondeur
    table_frame.configure(highlightbackground="white", highlightthickness=2)

    # Création d'un canvas pour contenir la table et permettre le défilement
    canvas = tk.Canvas(table_frame, width=1190, height=700)  # Fixer la largeur, hauteur ajustable
    canvas.pack(side="left", fill="both", expand=True)

    # Créer et personnaliser la scrollbar (en thème sombre)
    scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=canvas.yview, style="Custom.Vertical.TScrollbar")
    scrollbar.pack(side="right", fill="y")

    # Lier la scrollbar au canvas
    canvas.configure(yscrollcommand=scrollbar.set)

    # Création d'un cadre pour contenir la table
    grid_frame = tk.Frame(canvas, bg="#ffffff")
    canvas.create_window((0, 0), window=grid_frame, anchor="nw")

    # Création des labels pour les en-têtes de colonnes
    for col_index, col in enumerate(columns):
        col_label = tb.Label(grid_frame, text=col, font=("Arial", 12, "bold"), bootstyle="info", anchor="center")
        col_label.grid(row=0, column=col_index, padx=5, pady=5, sticky="nsew")  # Centrer l'en-tête et étirer horizontalement

    # Affichage des données ligne par ligne avec texte centré
    for row_index, row in enumerate(rows, start=1):
        for col_index, value in enumerate(row):
            cell_label = tb.Label(grid_frame, text=value, font=("Arial", 10), bootstyle="light", anchor="center")
            cell_label.grid(row=row_index, column=col_index, padx=5, pady=5, sticky="nsew")  # Centrer horizontal et vertical


        if role == "Administrateur":
            nom_id = cursor.description[0][0]
            identifiant = row[0]  # Suppose que l'ID est dans la première colonne
            
            # Ajouter les boutons Modifier et Supprimer dans la colonne "Actions"
            btn_modifier = tb.Button(
                grid_frame, 
                text=f"Modifier",  
                bootstyle="warning-outline", 
                width=8, 
                padding=(2, 2),
                command=lambda id=identifiant: modifier_ligne(id, nom_id, cursor, db, table_name, table_window, parent_window, role)
            )
            

            # Créer le bouton "Supprimer" avec l'identifiant dans le texte
            btn_supprimer = tb.Button(
                grid_frame, 
                text=f"Supprimer",  
                bootstyle="danger-outline", 
                width=10, 
                padding=(2, 2),
                command=lambda id=identifiant: supprimer_ligne(id, nom_id, cursor, db, table_name, table_window, parent_window, role)
            )

            # Placer les boutons côte à côte avec un espace d'écart
            btn_modifier.grid(row=row_index, column=len(columns)-1, padx=(5, 90), pady=5, sticky="w")  
            btn_supprimer.grid(row=row_index, column=len(columns)-1, padx=(90, 5), pady=5, sticky="e")  

    # Mettre à jour le canvas pour refléter la taille totale du contenu
    grid_frame.update_idletasks()  # S'assurer que le canvas soit correctement ajusté

    # Ajuster la taille du canvas pour que la scrollbar fonctionne
    canvas.config(scrollregion=canvas.bbox("all"))

    # Créer des colonnes et des lignes qui s'ajustent à la taille de la fenêtre
    for col_index in range(len(columns)):
        grid_frame.grid_columnconfigure(col_index, weight=1)  # Permet à chaque colonne de se redimensionner
    for row_index in range(len(rows) + 1):  # +1 pour inclure les en-têtes
        grid_frame.grid_rowconfigure(row_index, weight=1)  # Permet à chaque ligne de se redimensionner

    # Création des boutons sous l'affichage de la table
    btn_frame = tk.Frame(table_window)
    btn_frame.pack(pady=10, fill="x", padx=10)

    if role == "Administrateur":
        # Positionner les boutons pour les centrer horizontalement
        btn_insert = tb.Button(btn_frame, text="Insérer", bootstyle="info-outline", width=10, 
                            command=lambda: inserer_ligne(cursor, db, table_name, parent_window, role, table_window))
        btn_insert.grid(row=0, column=0, padx=10)  # Espacement horizontal entre les boutons

        btn_delete = tb.Button(btn_frame, text="Vider la table", bootstyle="danger-outline", width=11,
                        command=lambda: vider_table(cursor, db, table_name, table_window, parent_window, role))
        btn_delete.grid(row=0, column=2, padx=10)

    # Ajouter un espace invisible entre les colonnes pour centrer les boutons
    btn_frame.grid_columnconfigure(0, weight=1)
    btn_frame.grid_columnconfigure(1, weight=1)
    btn_frame.grid_columnconfigure(2, weight=1)

    # Bouton Retour (en bas à gauche) - réaffiche l'ancienne fenêtre en plein écran
    btn_retour = tb.Button(table_window, text="Retour", bootstyle="primary", 
                           command=lambda: [table_window.destroy(), parent_window.deiconify(), parent_window.state("zoomed")])
    btn_retour.pack(side="left", padx=10, pady=10, anchor="w")
    
    # Bouton Quitter (en bas à droite)
    btn_quitter = tb.Button(table_window, text="Quitter", bootstyle="danger", command=table_window.destroy)
    btn_quitter.pack(side="right", padx=10, pady=10, anchor="e")


def modifier_ligne(identifiant, nom_id, cursor, db, table_name, table_window, parent_window, role):
    """Ouvre une fenêtre pour modifier une ligne spécifique de la table."""
    
    # Masquer la fenêtre actuelle
    table_window.withdraw()

    # Créer une nouvelle fenêtre
    modif_window = tk.Toplevel()
    modif_window.title(f"Modifier l'entrée {identifiant}")
    modif_window.state("zoomed") 

    header_label = tb.Label(modif_window, text=f"Modification", font=("Arial", 16, "bold"), bootstyle="info")
    header_label.grid(row=0, column=0, columnspan=2, padx=10, pady=10, sticky="ew")
    
    # Récupérer les données actuelles de la ligne
    cursor.execute(f"SELECT * FROM {table_name} WHERE {nom_id} = %s", (identifiant,))
    row = cursor.fetchone()
    columns = [desc[0] for desc in cursor.description]  # Récupération des noms de colonnes

    # Liste pour stocker les champs de saisie
    entry_vars = {}

    # Création des champs de saisie pour chaque colonne
    for i, col_name in enumerate(columns):
        label = tk.Label(modif_window, text=col_name, font=("Arial", 10, "bold"))
        label.grid(row=1+i, column=0, padx=10, pady=5, sticky="w")

        entry_var = tk.StringVar(value=row[i])
        entry = tk.Entry(modif_window, textvariable=entry_var)
        entry.grid(row=1+i, column=1, padx=10, pady=5, sticky="w")

        entry_vars[col_name] = entry_var  # Stocker la variable associée

    # Bouton pour valider la modification
    def valider_modification():
        try:
            new_values = {col: entry_vars[col].get() for col in columns}
            set_clause = ", ".join(f"{col} = %s" for col in columns)  # Générer la clause SET

            # Exécuter la requête de mise à jour
            cursor.execute(
                f"UPDATE {table_name} SET {set_clause} WHERE {nom_id} = %s",
                list(new_values.values()) + [identifiant]
            )
            db.commit()

            # Fermer la fenêtre de modification et recharger la table
            voir_table(cursor, table_name, parent_window, role)
            messagebox.showinfo("Succès", f"La ligne a été modifiée avec succès.")
            modif_window.destroy()
            table_window.destroy()

        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la modification : {e}")

    btn_valider = tb.Button(modif_window, text="Valider", bootstyle="success-outline", command=valider_modification)
    btn_valider.grid(row=1+len(columns), column=0, columnspan=2, pady=10)

    # Bouton Retour
    btn_annuler = tb.Button(modif_window, text="Annuler", bootstyle="danger-outline",
                           command=lambda: [modif_window.destroy(), voir_table(cursor, table_name, parent_window, role)])
    btn_annuler.grid(row=1+len(columns) + 1, column=0, columnspan=2, pady=10)



def supprimer_ligne(identifiant, nom_id, cursor, db, table_name, table_window, parent_window, role):
    """Supprime une ligne de la table et met à jour l'affichage."""
    confirmation = messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer toutes les tables?")
    
    if confirmation:
        try:
            # Exécuter la suppression
            cursor.execute(f"DELETE FROM {table_name} WHERE {nom_id} = %s", (identifiant,))
            db.commit()  

            # Fermer la fenêtre actuelle et rouvrir la table mise à jour
            voir_table(cursor, table_name, parent_window, role)
            messagebox.showinfo("Succès", f"La ligne a été supprimée avec succès.")
            table_window.destroy()
        
        except Exception as e:
            messagebox.showerror("Erreur", f"Une erreur est survenue lors de la suppression : {e}")



def vider_table(cursor, db, table_name, table_window, parent_window, role):
    """Vide la table en désactivant temporairement les contraintes de clé étrangère."""
    
    confirmation = messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer toutes les tables?")
    
    if confirmation:
        # Vérifier si la table est vide
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        row_count = cursor.fetchone()[0]

        if row_count == 0:
            # Si la table est déjà vide, afficher un message d'erreur
            messagebox.showerror("Erreur", f"La table {table_name} est déjà vide.")
        else:
            try:
                # Désactiver les contraintes de clé étrangère
                cursor.execute("SET FOREIGN_KEY_CHECKS = 0;")
                # Supprimer toutes les données de la table
                cursor.execute(f"DELETE FROM {table_name}")
                db.commit()  # Appliquer les modifications à la base de données
                # Réactiver les contraintes de clé étrangère
                cursor.execute("SET FOREIGN_KEY_CHECKS = 1;")
                db.commit()

                messagebox.showinfo("Succès", f"La table {table_name} a été vidée avec succès.")
                voir_table(cursor, table_name, parent_window, role)
                table_window.destroy()  # Fermer la fenêtre de la table
            except Exception as e:
                # Gérer les erreurs en cas de problème avec la suppression
                messagebox.showerror("Erreur", f"Une erreur est survenue lors de la suppression : {e}")



def open_permissions_page(root):
    """Ouvre la fenêtre des permissions avec icônes pour les autorisations."""
    root.withdraw()
    permissions_window = tb.Toplevel(root)
    permissions_window.title("Permissions")
    permissions_window.state("zoomed")

    # Cadre principal aligné en haut
    main_frame = tk.Frame(permissions_window)
    main_frame.pack(pady=10, anchor="n")

    tb.Label(main_frame, text="Permissions", font=("Arial", 16, "bold"), bootstyle="info").grid(row=0, column=0, columnspan=2, pady=10, sticky="n")
    tb.Label(main_frame, text="Sélectionner un rôle :", font=("Arial", 12)).grid(row=1, column=0, columnspan=2, pady=5, sticky="n")

    role_var = tk.StringVar()
    role_dropdown = ttk.Combobox(main_frame, textvariable=role_var, values=["Utilisateur", "Administrateur"], state="readonly")
    role_dropdown.grid(row=2, column=0, columnspan=2, pady=5, sticky="n")
    role_dropdown.current(0)

    # Conteneur des permissions aligné en haut
    frame_permissions = tk.Frame(main_frame)
    frame_permissions.grid(row=3, column=0, columnspan=2, pady=10)

    # Charger les images
    global img_valide, img_interdit
    img_valide = ImageTk.PhotoImage(Image.open("img/valide.png").resize((20, 20)))
    img_interdit = ImageTk.PhotoImage(Image.open("img/interdit.png").resize((20, 20)))

    # Définition des permissions par rôle
    permissions = {
        "Administrateur": [
            ("Consulter toutes les données", "valide"),
            ("Exécuter les requêtes", "valide"),
            ("Ajouter, modifier et supprimer", "valide"),
        ],
        "Utilisateur": [
            ("Consulter toutes les données", "valide"),
            ("Exécuter les requêtes", "valide"),
            ("Ajout, modification et suppression interdites", "interdit"),
        ]
    }

    def update_permissions(event=None):
        """Met à jour l'affichage des permissions avec icônes."""
        for widget in frame_permissions.winfo_children():
            widget.destroy()

        role_choisi = role_var.get()
        for i, (permission, type_permission) in enumerate(permissions[role_choisi]):
            icon = img_valide if type_permission == "valide" else img_interdit
            
            label_img = tk.Label(frame_permissions, image=icon)
            label_img.grid(row=i, column=0, padx=10, pady=5, sticky="e")
            label_text = tk.Label(frame_permissions, text=permission, font=("Arial", 12))
            label_text.grid(row=i, column=1, padx=10, pady=5, sticky="w")

    role_dropdown.bind("<<ComboboxSelected>>", update_permissions)
    update_permissions()

    # Boutons Retour et Quitter alignés en bas
    frame_buttons = tk.Frame(main_frame)
    frame_buttons.grid(row=4, column=0, columnspan=2, pady=20)

    btn_retour = tb.Button(frame_buttons, text="Retour", bootstyle="primary", 
                           command = lambda: [permissions_window.destroy(), root.deiconify(), root.state('zoomed')])
    btn_retour.grid(row=0, column=0, padx=10, pady=5, sticky="e")

    btn_quitter = tb.Button(frame_buttons, text="Quitter", bootstyle="danger", command=root.destroy)
    btn_quitter.grid(row=0, column=1, padx=10, pady=5, sticky="w")
    
    
    
def ouvrir_csv(fichier):
    """ Ouvre un fichier CSV dans Excel. """
    os.system(f'start excel "{fichier}"')
    

def afficher_fichiers_csv(frame_csv, btn_csv, btn_masquer_csv):
    """ Affiche les fichiers CSV disponibles dans le dossier csv/. """
    # Supprime les anciens widgets
    for widget in frame_csv.winfo_children():
        widget.destroy()
    
    # Liste des fichiers CSV
    fichiers_csv = ["client.csv", "entree.csv", "saunier.csv", "sortie.csv"]
    
    # Création du conteneur avec un fond gris foncé
    container = tb.Frame(frame_csv, bootstyle="dark")
    container.grid(row=0, column=1, padx=5, pady=5, sticky="ne")  
    
    btn_csv.grid_forget()
    btn_masquer_csv.grid(row=0, column=1, sticky="ne")
    
    # Label d'en-tête
    label_entete = tb.Label(container, text="Fichiers CSV disponibles :", font=("Arial", 12, "bold"),
                            bootstyle="info", background="#333", foreground="white")
    label_entete.grid(row=0, column=0, padx=10, pady=5, sticky="w")
    
    # Variables de stockage des cases à cocher
    selected_files = {}
    
    def update_selected_files():
        selected = [f for f, var in selected_files.items() if var.get()]
        label_selected.config(text=f"Insérer dans la base de données\nles données des fichiers : {', '.join(selected) if selected else 'Aucun'}")
    
    # Affichage des fichiers avec cases à cocher
    for i, fichier in enumerate(fichiers_csv, start=1):
        var = tk.BooleanVar()
        selected_files[fichier] = var

        frame_file = tb.Frame(container, bootstyle="dark")
        frame_file.grid(row=i, column=0, padx=10, pady=2, sticky="w")
        
        cb_fichier = tb.Checkbutton(frame_file, variable=var, command=update_selected_files, bootstyle="primary")
        cb_fichier.grid(row=0, column=0, padx=5, sticky="w")
        
        btn_fichier = tb.Button(frame_file, text=fichier, bootstyle="info-outline", 
                                command=lambda f=fichier: ouvrir_csv(os.path.join("csv", f)))
        btn_fichier.grid(row=0, column=1, sticky="w")
    
    # Label affichant les fichiers sélectionnés
    label_selected = tb.Label(container, text="Insérer dans la base de données\nles données des fichiers : Aucun", 
                              font=("Arial", 10), bootstyle="info", background="#333", foreground="white")
    label_selected.grid(row=len(fichiers_csv) + 1, column=0, padx=10, pady=5, sticky="w")
    
    btn_inserer_csv = tb.Button(container, text="Insérer", bootstyle="success-outline", padding=10, command=lambda: inserer_fichier_csv(selected_files, db, cursor))
    btn_inserer_csv.grid(row=len(fichiers_csv) + 2, column=0, padx=10, pady=5, sticky="w")


def inserer_fichier_csv(selected_files, db, cursor):
    """ Insertion des fichiers CSV dans la base de données. """
    
    requetes_sql = {
        "client.csv": [("INSERT INTO Client VALUES (%s, %s, %s, %s)", [0, 1, 2, 3])],
        "entree.csv": [("INSERT INTO Entree VALUES (%s, %s, %s, %s, %s)", [0, 1, 2, 3, 4])],
        "saunier.csv": [("INSERT INTO Saunier VALUES (%s, %s, %s, %s)", [0, 1, 2, 3])],
        "sortie.csv": [
            ("INSERT INTO Sortie VALUES (%s, %s, %s)", [0, 1, 2]),
            ("INSERT INTO Concerner VALUES (%s, %s, %s)", [3, 0, 4])
        ]
    }

    # Vérification de l'existence des tables dans la base de données
    def verifier_tables_existantes(tables, cursor):
        """ Vérifie si les tables existent dans la base de données. """
        for table in tables:
            cursor.execute(f"SHOW TABLES LIKE '{table}'")
            result = cursor.fetchone()
            if result is None:
                messagebox.showerror("Erreur", f"La table {', '.join(tables)} n'existe pas dans la base de données.")
                return False
        return True

    fichiers_selectionnes = [f for f, var in selected_files.items() if var.get()]

    if fichiers_selectionnes:
        # Récupérer les noms des tables depuis les requêtes
        tables_a_verifier = [requetes[0][0].split(" ")[2] for fichier, requetes in requetes_sql.items() if fichier in fichiers_selectionnes]
        
        if not verifier_tables_existantes(tables_a_verifier, cursor):
            return  # Si une table n'existe pas, on arrête l'exécution

        # Insertion des données dans les tables
        for fichier in fichiers_selectionnes:
            if fichier in requetes_sql:
                for requete, colonnes in requetes_sql[fichier]:
                    chemin_fichier = os.path.join("csv", fichier)
                    try:
                        traiter_csv(chemin_fichier, requete, colonnes, db, cursor)
                    except Exception as e:
                        messagebox.showerror("Erreur", f"Erreur lors du traitement du fichier {fichier} : {str(e)}")
                        return
        messagebox.showinfo("Succès", "Les données ont été insérées avec succès.")
    else:
        messagebox.showwarning("Aucun fichier sélectionné", "Veuillez sélectionner au moins un fichier avant l'insertion.")
        
    

def masquer_fichiers_csv(frame_csv, btn_csv, btn_masquer_csv):
    """ Masque les fichiers CSV affichés. """
    for widget in frame_csv.winfo_children():
        widget.destroy()
    
    btn_masquer_csv.grid_forget()
    btn_csv.grid(row=0, column=1, sticky="ne")  
        
    
def afficher_requetes(frame_requetes, db_connection, btn_requetes, btn_masquer_requetes):
    for widget in frame_requetes.winfo_children():
        widget.destroy()
        
    btn_requetes.grid_forget()
    btn_masquer_requetes.grid(row=0, column=1, pady=5)
    
    requete_sql = {
        "Insert pour un client": """INSERT INTO client (numCli, nomCli, precisionCli, villeCli)
    VALUES (12, 'DUPONT', 'Lucie', 'NIORT');""",

        "Afficher le stock actuel de chaque produit": """SELECT numPdt, libPdt, stockPdt FROM produit;""",

        "Afficher les prix de vente des produits en 2024": """SELECT p.numPdt, pr.libPdt, p.PrixVente, p.Annee 
    FROM prix p 
    JOIN produit pr ON p.numPdt = pr.numPdt 
    WHERE p.Annee = 2024;""",

        "Afficher les produits dont le prix de vente a augmenté en 2024 par rapport à 2023": """SELECT p2024.numPdt, pr.libPdt, p2023.PrixVente AS Prix_2023, p2024.PrixVente AS Prix_2024
    FROM prix p2024
    JOIN prix p2023 ON p2024.numPdt = p2023.numPdt AND p2024.Annee = 2024 AND p2023.Annee = 2023
    JOIN produit pr ON p2024.numPdt = pr.numPdt
    WHERE p2024.PrixVente > p2023.PrixVente;""",

        "Créer une vue pour afficher les commandes des clients avec les produits associés": """CREATE VIEW vue_commandes_clients AS
    SELECT c.numCli, c.nomCli, c.villeCli, s.numSort, s.dateSort, p.libPdt, co.qteSort
    FROM client c
    JOIN sortie s ON c.numCli = s.numCli
    JOIN concerner co ON s.numSort = co.numSort
    JOIN produit p ON co.numPdt = p.numPdt;""",

        "Nombre de commandes passées par chaque client": """SELECT s.numCli, c.nomCli, COUNT(s.numSort) AS NombreCommandes
    FROM sortie s
    JOIN client c ON s.numCli = c.numCli
    GROUP BY s.numCli, c.nomCli
    ORDER BY NombreCommandes DESC;""",

        "Trouver les clients qui ont effectué plus de 1 sortie": """SELECT c.numCli, c.nomCli, c.villeCli, COUNT(s.numSort) AS NombreDeSorties
    FROM client c
    JOIN sortie s ON c.numCli = s.numCli
    GROUP BY c.numCli, c.nomCli, c.villeCli
    HAVING COUNT(s.numSort) > 1;""",

        "Consulter les commandes d'un client spécifique à partir de la vue": """SELECT *
    FROM vue_commandes_clients
    WHERE numCli = 1;""",

        "Chiffre d'affaire produit par année": """SELECT p.Annee, SUM(c.qteSort * p.PrixVente) AS ChiffreAffaires
    FROM concerner c
    JOIN prix p ON c.numPdt = p.numPdt
    GROUP BY p.Annee;""",

        "Trouver les clients qui n'ont pas acheté un produit particulier": """SELECT c.numCli, c.nomCli, c.villeCli
    FROM client c
    WHERE c.numCli NOT IN (
        SELECT s.numCli
        FROM sortie s
        JOIN concerner co ON s.numSort = co.numSort
        JOIN produit p ON co.numPdt = p.numPdt
        WHERE p.libPdt = 'Gros sel');"""
    }

    def get_selected_query():
        selected_key = combobox_requete.get()
        return requete_sql.get(selected_key, "Aucune requête sélectionnée")


    def execute_query():
        query = get_selected_query()
        if query == "Aucune requête sélectionnée":
            result_label.config(text="Veuillez sélectionner une requête.", foreground="red")
            return
    
        try:
            cursor = db_connection.cursor()
            cursor.execute(query)
            rows = cursor.fetchall()
            db_connection.commit()
    
            # Nettoyage de l'affichage précédent
            for widget in result_frame.winfo_children():
                widget.destroy()
    
            if not rows:
                result_label.config(text="Requête exécutée avec succès (aucun résultat).", foreground="green")
                return
    
            # Colonnes
            columns = [desc[0] for desc in cursor.description]
    
            # Affichage Treeview
            tree = ttk.Treeview(result_frame, columns=columns, show="headings")
    
            for col in columns:
                tree.heading(col, text=col)
                tree.column(col, anchor="center", width=100)
    
            for row in rows:
                tree.insert("", "end", values=row)
    
            for i, col in enumerate(columns):
                max_width = max(len(str(row[i])) for row in rows) * 7
                tree.column(col, width=max(100, min(max_width, 300)))
    
            scrollbar_y = ttk.Scrollbar(result_frame, orient="vertical", command=tree.yview)
            scrollbar_x = ttk.Scrollbar(result_frame, orient="horizontal", command=tree.xview)
            tree.configure(yscrollcommand=scrollbar_y.set, xscrollcommand=scrollbar_x.set)
    
            tree.grid(row=0, column=0, sticky="nsew")
            scrollbar_y.grid(row=0, column=1, sticky="ns")
            scrollbar_x.grid(row=1, column=0, sticky="ew")
    
            result_frame.grid_propagate(True)
            result_label.config(text="", foreground="black")
    
            # ==== Génération du graphique selon la requête ====
            selected_key = combobox_requete.get()
            labels, values = [], []
            xlabel = ylabel = title = ""
    
            if selected_key == "Afficher le stock actuel de chaque produit":
                labels = [str(row[1]) for row in rows]
                values = [float(row[2]) for row in rows]
                xlabel, ylabel, title = "Produits", "Stock", "Stock par Produit"
    
            elif selected_key == "Afficher les prix de vente des produits en 2024":
                labels = [str(row[1]) for row in rows]
                values = [float(row[2]) for row in rows]
                xlabel, ylabel, title = "Produits", "Prix de vente", "Prix des Produits (2024)"
    
            elif selected_key == "Nombre de commandes passées par chaque client":
                labels = [str(row[1]) for row in rows]
                values = [int(row[2]) for row in rows]
                xlabel, ylabel, title = "Clients", "Nombre de commandes", "Commandes par Client"
    
            elif selected_key == "Chiffre d'affaire produit par année":
                labels = [str(row[0]) for row in rows]
                values = [float(row[1]) for row in rows]
                xlabel, ylabel, title = "Années", "Chiffre d'affaires", "Chiffre d'Affaires par Année"
    
            # Affichage du graphique si applicable
            if labels and values:
                try:
                    # Choisir une taille de graphique différente pour la requête 6
                    if selected_key == "Nombre de commandes passées par chaque client":
                        fig, ax = plt.subplots(figsize=(7, 4))  # Légèrement plus étroit
                    else:
                        fig, ax = plt.subplots(figsize=(8, 4))
    
                    ax.bar(labels, values, color='skyblue')
                    ax.set_xlabel(xlabel)
                    ax.set_ylabel(ylabel)
                    ax.set_title(title)
    
                    # Rotation personnalisée pour la requête 6
                    if selected_key == "Nombre de commandes passées par chaque client":
                        ax.tick_params(axis='x', rotation=90, labelsize=8, pad=5)
                    else:
                        ax.tick_params(axis='x', rotation=45, labelsize=10, pad=10)
    
                    ax.grid(axis='y', linestyle='--', alpha=0.7)
                    fig.tight_layout()
    
                    canvas = FigureCanvasTkAgg(fig, master=result_frame)
                    canvas.draw()
                    canvas.get_tk_widget().grid(row=2, column=0, columnspan=2, pady=10)
    
                except Exception as e:
                    print(f"Erreur d'affichage du graphique : {e}")
    
        except Exception as e:
            error_message = str(e)
            max_length = 80
            wrapped_message = "\n".join(error_message[i:i+max_length] for i in range(0, len(error_message), max_length))
            result_label.config(text=f"Erreur :\n{wrapped_message}", foreground="red")


            

    # Configuration de l'interface
    requetes_options = list(requete_sql.keys())
    combobox_requete = ttk.Combobox(frame_requetes, values=requetes_options, 
                                state="readonly", width=65, justify="center")
    combobox_requete.set("Choisir la requête")
    combobox_requete.grid(row=0, column=0, padx=5, pady=5)

    btn_executer = tb.Button(frame_requetes, text="💾 Exécuter", 
                            bootstyle="success-outline", 
                            command=execute_query)
    btn_executer.grid(row=1, column=0, padx=5, pady=10)

    result_frame = tk.Frame(frame_requetes)
    result_frame.grid(row=2, column=0, padx=5, pady=10, sticky="nsew")

    # Permettre au frame de s'ajuster dynamiquement
    result_frame.grid_columnconfigure(0, weight=1)
    result_frame.grid_rowconfigure(0, weight=1)

    result_label = tk.Label(frame_requetes, text="", font=("Arial", 12))
    result_label.grid(row=3, column=0, padx=5, pady=5)

    return get_selected_query


def masquer_requetes(frame_requetes, btn_requetes, btn_masquer_requetes):
    """ Masque les fichiers CSV affichés. """
    for widget in frame_requetes.winfo_children():
        widget.destroy()
    
    btn_masquer_requetes.grid_forget()
    btn_requetes.grid(row=0, column=1, pady=5)
    
    
def create(cursor, db, frame_tables, btn_afficher, btn_masquer, role):
    with open('selmarin_create.sql', 'r') as file:
        sql_script = file.read()

    tables_existantes = []
    tables_creees = []

    for statement in sql_script.split(';'):
        statement = statement.strip()
        if statement:
            try:
                cursor.execute(statement)
                if statement.upper().startswith("CREATE TABLE"):
                    table_name = statement.split()[2].strip('()`')
                    tables_creees.append(table_name)
            except mysql.connector.Error as err:
                if statement.upper().startswith("CREATE TABLE"):
                    table_name = statement.split()[2].strip('()`')
                    tables_existantes.append(table_name)

    db.commit()
    afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role)

    message = ""
    if tables_existantes:
        message += f"Tables déjà créées : {', '.join(tables_existantes)}. "
    if tables_creees:
        message += f"Tables créées : {', '.join(tables_creees)}."

    messagebox.showinfo("Résultat", message)


            
            
def drop_all_tables(cursor, db, frame_tables, btn_afficher, btn_masquer, role):
    
    confirmation = messagebox.askyesno("Confirmation", f"Voulez-vous vraiment supprimer toutes les tables?")
    
    if confirmation:
        # Désactiver temporairement les contraintes de clé étrangère
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0;")
        
        # Récupérer toutes les tables
        cursor.execute("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE';")
        tables = [table[0] for table in cursor.fetchall()]
        
        # Récupérer toutes les vues
        cursor.execute("SHOW FULL TABLES WHERE Table_type = 'VIEW';")
        views = [view[0] for view in cursor.fetchall()]
        
        if not tables and not views:
            messagebox.showinfo("Résultat", "Aucune table ou vue à supprimer.")
            return
        
        # Supprimer toutes les vues
        for view in views:
            cursor.execute(f"DROP VIEW IF EXISTS `{view}`;")
        
        # Supprimer toutes les tables
        for table in tables:
            cursor.execute(f"DROP TABLE IF EXISTS `{table}`;")
        
        # Réactiver les contraintes de clé étrangère
        cursor.execute("SET FOREIGN_KEY_CHECKS = 1;")
        
        db.commit()
        afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role)
        messagebox.showinfo("Résultat", "Toutes les tables et vues ont été supprimées avec succès.")


def inserer_donnees(cursor, db, frame_tables, btn_afficher, btn_masquer, role):
    try:
        with open('selmarin_insert.sql', 'r') as file:
            sql_script = file.read()
    except FileNotFoundError:
        messagebox.showerror("Erreur", "Le fichier 'selmarin_insert.sql' est introuvable.")
        return

    tables_reussies = []
    tables_erreurs = []

    for statement in sql_script.split(';'):
        if statement.strip():
            try:
                cursor.execute(statement)
                if "INTO" in statement.upper():
                    table_name = statement.upper().split("INTO")[1].split()[0].strip('()`')
                    tables_reussies.append(table_name.upper())
            except mysql.connector.Error as err:
                try:
                    table_name = statement.upper().split("INTO")[1].split()[0].strip('()`')
                    tables_erreurs.append(table_name.upper())
                except IndexError:
                    pass  # Si la table ne peut pas être extraite, on ignore cette erreur
                print(f"Erreur lors de l'insertion dans {table_name.upper()} : {err}")

    db.commit()
    afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role)

    message = ""
    if tables_reussies:
        message += f"Données insérées dans les tables : {', '.join(tables_reussies)}.\n"
    if tables_erreurs:
        message += f"Erreurs lors de l'insertion dans : {', '.join(tables_erreurs)}."

    if not message:
        message = "Aucune instruction trouvée dans le fichier SQL."

    messagebox.showinfo("Résultat de l'insertion", message)



def create_ui(root, cursor, role):
    root.withdraw()
    new_window = tb.Toplevel(root)  
    new_window.title("\U0001F4CA Visualisation de la Base de Données")
    new_window.state("zoomed")

    tb.Label(new_window, text=f"Bienvenue, {role}", font=("Arial", 18, "bold"), bootstyle="info").grid(row=0, column=0, columnspan=3, pady=10)
    
    frame_top = tb.Frame(new_window)
    frame_top.grid(row=1, column=0, columnspan=3, sticky="ew", padx=10, pady=10)
    frame_top.grid_columnconfigure(0, weight=1)
    frame_top.grid_columnconfigure(1, weight=1)
    frame_top.grid_columnconfigure(2, weight=1)
    
    frame_buttons = tb.Frame(frame_top)
    frame_buttons.grid(row=0, column=0, sticky="w")
    
    frame_csv_button = tb.Frame(frame_top)
    frame_csv_button.grid(row=0, column=2, sticky="e", padx=20)

    frame_canvas = tb.Frame(new_window)
    frame_canvas.grid(row=2, column=0, columnspan=3, sticky="nsew", padx=10, pady=10)
    new_window.grid_rowconfigure(2, weight=1)
    new_window.grid_columnconfigure(0, weight=1)
    
    canvas = tk.Canvas(frame_canvas, bg="#1e1e1e", highlightthickness=0)
    scrollbar_y = ttk.Scrollbar(frame_canvas, orient="vertical", command=canvas.yview, style="Custom.TScrollbar")
    frame_tables = tb.Frame(canvas)
    
    frame_tables.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=frame_tables, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar_y.set)
    
    canvas.grid(row=0, column=0, sticky="nsew")
    scrollbar_y.grid(row=0, column=1, sticky="ns")
    frame_canvas.grid_rowconfigure(0, weight=1)
    frame_canvas.grid_columnconfigure(0, weight=1)
    
    frame_csv = tb.Frame(frame_canvas)
    frame_csv.grid(row=0, column=0, padx=10, sticky="ne")  # Place-le en haut à droite du canvas
    frame_canvas.grid_columnconfigure(0, weight=1)
    
    btn_afficher = tb.Button(frame_buttons, text="\U0001F50D Afficher les Tables", 
                             command=lambda: afficher_tables(cursor, frame_tables, btn_afficher, btn_masquer, role), 
                             bootstyle="success-outline")
    btn_afficher.grid(row=0, column=0, padx=5)
    
    btn_masquer = tb.Button(frame_buttons, text="\U0001F6AB Masquer les Tables", 
                            command=lambda: masquer_tables(frame_tables, btn_afficher, btn_masquer), 
                            bootstyle="danger-outline")
    btn_masquer.grid(row=0, column=1)
    btn_masquer.grid_remove()
    
    if role == "Administrateur":
        btn_csv = tb.Button(frame_csv_button, text="\U0001F4C1 Afficher les fichiers CSV", 
                            command=lambda: afficher_fichiers_csv(frame_csv, btn_csv, btn_masquer_csv), 
                            bootstyle="info-outline")
        btn_csv.grid(row=0, column=0, sticky="ne")
    
        btn_masquer_csv = tb.Button(frame_csv_button, text="\U0001F6AB Masquer les fichiers CSV", 
                                    command=lambda: masquer_fichiers_csv(frame_csv, btn_csv, btn_masquer_csv), 
                                    bootstyle="danger-outline")
        btn_masquer_csv.grid(row=0, column=1, sticky="ne")
        btn_masquer_csv.grid_remove()
    
        # Frame pour "Créer les Tables" + "Supprimer"
        frame_create = tb.Frame(frame_top)
        frame_create.grid(row=0, column=1, sticky="ew", padx=10)  # Ajuster l'alignement
    
        btn_create = tb.Button(frame_create, text="\U0001F50D Créer les Tables", 
                               command=lambda: create(cursor, db, frame_tables, btn_afficher, btn_masquer, role),
                               bootstyle="success-outline")
        btn_create.grid(row=0, column=0, pady=5, sticky="ew", padx=10)
    
        btn_supprimer = tb.Button(frame_create, text="\U0001F5D1 Supprimer toutes les Tables", 
                                  command=lambda: drop_all_tables(cursor, db, frame_tables, btn_afficher, btn_masquer, role),
                                  bootstyle="danger-outline")
        btn_supprimer.grid(row=0, column=1, pady=5, sticky="ew", padx=10)
    
        frame_insert = tb.Frame(frame_top)
        frame_insert.grid(row=0, column=2, sticky="w", padx=10) 

        btn_insert = tb.Button(frame_insert, text="\U0001F4E5 Insérer Données", 
                               command=lambda: inserer_donnees(cursor, db, frame_tables, btn_afficher, btn_masquer, role),
                               bootstyle="warning-outline")
        btn_insert.grid(row=0, column=0, pady=5, sticky="ew")

    
        frame_supprimer = tb.Frame(frame_top)
        frame_supprimer.grid(row=0, column=1, columnspan=3, sticky="w")

        # Bouton "Créer les Tables"
        btn_supprimer = tb.Button(frame_create, text="\U0001F5D1 Supprimer toutes les Tables", 
                            command=lambda: drop_all_tables(cursor, db, frame_tables, btn_afficher, btn_masquer, role),
                            bootstyle="danger-outline")
        btn_supprimer.grid(row=0, column=1, pady=5, sticky="w", padx=10)
        

        frame_top.grid_columnconfigure(1, weight=1, minsize=900)
        
    # Frame pour afficher le bouton "Afficher Requêtes" aux 2/3 de la page
    frame_btn_requetes = tb.Frame(frame_top)
    frame_btn_requetes.grid(row=0, column=0, columnspan=3, padx=10, pady=10)
    frame_btn_requetes.grid_columnconfigure(1, weight=1)  # Permet d'ajuster la position
    
    frame_requetes = tb.Frame(frame_canvas)
    frame_requetes.grid(row=0, column=0, columnspan=3, padx=600, sticky="nsew")
    frame_requetes.grid_columnconfigure(0, weight=1)  # Permet d'ajuster la position

    # Bouton "Afficher Requêtes"
    btn_requetes = tb.Button(frame_btn_requetes, text="\U0001F4DD Afficher Requêtes", 
                             command=lambda: afficher_requetes(frame_requetes, db, btn_requetes, btn_masquer_requetes),
                             bootstyle="info-outline")
    btn_requetes.grid(row=0, column=1, pady=5)  

    btn_masquer_requetes = tb.Button(frame_btn_requetes, text="\U0001F6AB Masquer Requêtes", 
                             command=lambda: masquer_requetes(frame_requetes, btn_requetes, btn_masquer_requetes),
                             bootstyle="danger-outline")
    btn_masquer_requetes.grid(row=0, column=1, pady=5)  
    btn_masquer_requetes.grid_remove()


    frame_bottom = tb.Frame(new_window)
    frame_bottom.grid(row=3, column=0, columnspan=3, sticky="ew", pady=10)
    frame_bottom.grid_columnconfigure(0, weight=1)
    frame_bottom.grid_columnconfigure(1, weight=1)
    frame_bottom.grid_columnconfigure(2, weight=1)
    
    btn_retour = tb.Button(frame_bottom, text="Retour", bootstyle="primary", 
                           command = lambda: [new_window.destroy(), root.deiconify(), root.state('zoomed')])
    btn_retour.grid(row=0, column=0, padx=10, sticky="w")
    
    btn_quitter = tb.Button(frame_bottom, text="Quitter", bootstyle="danger", command=root.destroy)
    btn_quitter.grid(row=0, column=2, padx=10, sticky="e")


def check_login(role_var, password_var, root, cursor):
    """ Vérifie le mot de passe et redirige vers l'interface. """
    role = role_var.get()
    password = password_var.get()
    valid_passwords = {"Utilisateur": "0000", "Administrateur": "1234"}
    
    if role in valid_passwords and password == valid_passwords[role]:
        create_ui(root, cursor, role)
    else:
        messagebox.showerror("Erreur", "Mot de passe incorrect !")

def create_login(root, cursor):
    """ Crée l'interface de connexion avec grid(). """
    root.title("\U0001F511 Connexion")
    root.state("zoomed")
    root.columnconfigure(0, weight=1)

    # Frame du haut
    frame_top = tb.Frame(root)
    frame_top.grid(row=0, column=0, sticky="nw", padx=10, pady=5)
    
    permission_btn = tb.Button(frame_top, text="Voir permissions", bootstyle="info-outline",
                               command=lambda: open_permissions_page(root))
    permission_btn.grid(row=0, column=0, padx=5)

    # Titre
    title_label = tb.Label(root, text="Connexion", font=("Arial", 18, "bold"), bootstyle="info")
    title_label.grid(row=1, column=0, pady=10)

    # Frame principale
    frame = tb.Frame(root)
    frame.grid(row=2, column=0, pady=20)
    frame.columnconfigure(0, weight=1)

    # Label rôle
    tb.Label(frame, text="Choisir un rôle :", font=("Arial", 12)).grid(row=0, column=0, sticky="w", pady=2)
    
    # Dropdown rôle
    role_var = tk.StringVar()
    role_dropdown = ttk.Combobox(frame, textvariable=role_var, values=["Utilisateur", "Administrateur"], state="readonly")
    role_dropdown.grid(row=1, column=0, pady=5, sticky="ew")
    role_dropdown.current(0)

    # Label mot de passe
    tb.Label(frame, text="Mot de passe :", font=("Arial", 12)).grid(row=2, column=0, sticky="w", pady=2)
    
    # Champ mot de passe
    password_var = tk.StringVar()
    password_entry = tb.Entry(frame, textvariable=password_var, show="*", bootstyle="info")
    password_entry.grid(row=3, column=0, pady=5, sticky="ew")

    # Bouton connexion
    login_btn = tb.Button(frame, text="Se Connecter", bootstyle="success",
                          command=lambda: check_login(role_var, password_var, root, cursor))
    login_btn.grid(row=4, column=0, pady=10)

    # Bouton quitter
    quit_btn = tb.Button(frame, text="Quitter", bootstyle="danger", command=root.destroy)
    quit_btn.grid(row=5, column=0, pady=5)

    # Configuration pour que les éléments s'étendent correctement
    frame.grid_columnconfigure(0, weight=1)
    root.grid_columnconfigure(0, weight=1)

# Code principal
db, cursor = connect_db()
root = tb.Window(themename="darkly")
create_login(root, cursor)
root.mainloop()
