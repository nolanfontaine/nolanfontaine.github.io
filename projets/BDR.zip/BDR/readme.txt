★ Étapes pour configurer l'application Selmarin :

*1. Créer la base de données dans EasyPHP :
    - Ouvrir EasyPHP Dashboard.
    - Lancer phpMyAdmin.
    - Créer une nouvelle base de données nommée selmarinnolannoa.

*2. Importer les fichiers SQL :
    - Dans phpMyAdmin, sélectionner la base de données selmarinnolannoa.
    - Aller dans l’onglet Importer.
    - Importer le fichier selmarin_create.sql (structure de la base de données).
    - Puis importer le fichier selmarin_insert.sql (données à insérer).

*3. Installer les bibliothèques nécessaires en ligne de commande :
	- pip install mysql-connector-python
	- pip install ttkbootstrap

*4. Redémarrer le noyau Python :
    - Dans l’environnement de développement (ex. : Jupyter Notebook, VS Code), redémarrer le noyau pour que les bibliothèques soient bien prises en compte.

*5. En cas d’interface blanche ou grise :
    - Redémarrer à nouveau le noyau (ce problème peut être lié à ttkbootstrap).

*6. Lancer l’application :
    - Exécuter le fichier Python selmarin_ihm.py 

*7. Consulter la vidéo de présentation de l’application :
    - Regarder la vidéo fournie pour comprendre le fonctionnement et les fonctionnalités de l'application.