/*1. Insert pour un client*/
INSERT INTO client (numCli, nomCli, precisionCli, villeCli)
VALUES (12, 'DUPONT', 'Lucie', 'NIORT');

/*2. Afficher le stock actuel de chaque produit*/
SELECT numPdt, libPdt, stockPdt FROM produit;

/*3. Afficher les prix de vente des produits en 2024*/
SELECT p.numPdt, pr.libPdt, p.PrixVente, p.Annee 
FROM prix p 
JOIN produit pr ON p.numPdt = pr.numPdt 
WHERE p.Annee = 2024;

/*4. Afficher les produits dont le prix de vente a augmenté en 2024 par rapport à 2023*/
SELECT p2024.numPdt, pr.libPdt, p2023.PrixVente AS Prix_2023, p2024.PrixVente AS Prix_2024
FROM prix p2024
JOIN prix p2023 ON p2024.numPdt = p2023.numPdt AND p2024.Annee = 2024 AND p2023.Annee = 2023
JOIN produit pr ON p2024.numPdt = pr.numPdt
WHERE p2024.PrixVente > p2023.PrixVente;

/*5. Créer une vue pour afficher les commandes des clients avec les produits associés*/
CREATE VIEW vue_commandes_clients AS
SELECT c.numCli, c.nomCli, c.villeCli, s.numSort, s.dateSort, p.libPdt, co.qteSort
FROM client c
JOIN sortie s ON c.numCli = s.numCli
JOIN concerner co ON s.numSort = co.numSort
JOIN produit p ON co.numPdt = p.numPdt;

/*6. Nombre de commandes passées par chaque client*/
SELECT s.numCli, c.nomCli, COUNT(s.numSort) AS NombreCommandes
FROM sortie s
JOIN client c ON s.numCli = c.numCli
GROUP BY s.numCli, c.nomCli
ORDER BY NombreCommandes DESC;

/*7. Trouver les clients qui ont effectué plus de 1 sortie */
SELECT c.numCli, c.nomCli, c.villeCli, COUNT(s.numSort) AS NombreDeSorties
FROM client c
JOIN sortie s ON c.numCli = s.numCli
GROUP BY c.numCli, c.nomCli, c.villeCli
HAVING COUNT(s.numSort) > 1;

/*8. Consulter les commandes d'un client spécifique à partir de la vue*/
SELECT *
FROM vue_commandes_clients
WHERE numCli = 1;

/*9. Chiffre d'affaire produit par année*/
SELECT p.Annee, SUM(c.qteSort * p.PrixVente) AS ChiffreAffaires
FROM concerner c
JOIN prix p ON c.numPdt = p.numPdt
GROUP BY p.Annee;

/*10. Trouver les clients qui n'ont pas acheté un produit particulier*/
SELECT c.numCli, c.nomCli, c.villeCli
FROM client c
WHERE c.numCli NOT IN (
    SELECT s.numCli
    FROM sortie s
    JOIN concerner co ON s.numSort = co.numSort
    JOIN produit p ON co.numPdt = p.numPdt
    WHERE p.libPdt = 'Gros sel');


