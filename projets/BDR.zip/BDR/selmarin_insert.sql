INSERT INTO `saunier` (`numSau`, `nomSau`, `prenomSau`, `villeSau`) VALUES
(1, 'YVAN', 'Pierre', 'Ars-En-Ré'),
(2, 'PETIT', 'Marc', 'Loix');

INSERT INTO `produit` (`numPdt`, `libPdt`, `stockPdt`) VALUES
(1, 'Gros sel', 2000),
(2, 'Fleur de sel', 1000);

INSERT INTO `anneeprix` (`Annee`) VALUES
(2023), (2024), (2025), (2026), (2027), (2028), (2029), (2030);

INSERT INTO `client` (`numCli`, `nomCli`, `precisionCli`, `villeCli`) VALUES
(1, 'CAVANA', 'Marie', 'LA ROCHELLE'),
(2, 'BURLET', 'Michel', 'LAGORD'),
(3, 'PEUTOT', 'Maurice', 'LAGORD'),
(4, 'ORGEVAL', 'Centrale d’Achats', 'SURGERES');

INSERT INTO `prix` (`numPdt`, `Annee`, `PrixAchat`, `PrixVente`) VALUES
(1, 2023, 270, 280),
(1, 2024, 270, 290),
(1, 2025, 240, 300),
(2, 2023, 3900, 9500),
(2, 2024, 3800, 10000),
(2, 2025, 3500, 9000);

INSERT INTO `entree` (`numEnt`, `dateEnt`, `qteEnt`, `numPdt`, `numSau`) VALUES
(20241, '2024-06-16 00:00:00', 1000, 1, 1),
(20242, '2024-06-18 00:00:00', 500, 1, 2),
(20243, '2024-07-10 00:00:00', 1500, 2, 2);

INSERT INTO `sortie` (`numSort`, `dateSort`, `numCli`) VALUES
(20241, '2024-07-16 00:00:00', 1),
(20242, '2024-07-18 00:00:00', 1),
(20243, '2024-08-10 00:00:00', 2);

INSERT INTO `concerner` (`numPdt`, `numSort`, `qteSort`) VALUES
(1, 20241, 300),
(2, 20241, 400),
(1, 20242, 200),
(1, 20243, 100),
(2, 20243, 500);

COMMIT;
