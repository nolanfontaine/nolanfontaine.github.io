################################
# Travail 2
################################

library(FrF2)
library(FactoMineR)

### Question 1 : Construction du plan 2^(4-1)
# --------------------------------------------------------------------------

# Construction du plan factoriel 2^(4-1)
# nfactors = 4 (A, B, C, D)
# nruns = 2^(4-1) = 8 essais
# Correspond au "plan fractionnaire 2^(4-1)" pour 4 facteurs, limité à 8 essais.
plan <- FrF2(nruns = 8, nfactors = 4)

# Afficher le détail des confusions
# C'est la sortie de cette fonction qui répond à la question.
# C'est la relation de définition D=ABC
# et les confusions (aliasing) qui en découlent, comme A=BCD ou AB=CD.
summary(plan)


### Question 2-3 : Ajout d'intersection et Matrice d'Hadamard
# --------------------------------------------------------------------------

# Importation du fichier CSV
plan_importe <- read.table("./plan_sujet2026.csv", sep = ";", header = TRUE)

cat("Fichier CSV importé :\n")
plan_importe

# Codage du plan en -1 et +1
plan_brut <- data.frame(
  A = ifelse(plan_importe$Température == "180°C", -1, 1),
  D = ifelse(plan_importe$Pépites == "Industrielles", -1, 1),
  C = ifelse(plan_importe$Chocolat == "70%", -1, 1),
  B = ifelse(plan_importe$`Temps.de.cuisson` == "8 min", -1, 1), 
  Y = plan_importe$Notes
)

cat("\nPlan d'expérience codé (-1/+1) :\n")
plan_brut

# --- Ajout des interactions ---

don <- plan_brut
# On calcule les colonnes pour les interactions que l'on souhaite estimer.
don$AB <- don$A * don$B
don$AC <- don$A * don$C
don$AD <- don$A * don$D

cat("\nPlan avec interactions ajoutées :\n")
don

# --- Vérification de la matrice d'Hadamard ---

# On crée la matrice du modèle X (design matrix)
X <- model.matrix(~., data = don[, -5])

cat("\nMatrice des effets X :\n")
X

# Calcul de X' * X (X transposé fois X)
# La matrice X vérifie la propriété d'Hadamard (X'X=8I).
# Ce calcul vérifie cette propriété d'orthogonalité. On s'attend à une matrice diagonale avec des 8.
XtX <- t(X) %*% X

cat("\nVérification de la matrice d'Hadamard (résultat de X^t * X) :\n")
XtX



### Question 4 : Sélection du modèle optimal
# --------------------------------------------------------------------------


# --- Estimation des effets ---
# Formule d'estimation des coefficients pour un plan orthogonal : theta = (X'X)^-1 * X'Y
# Puisque X'X = 8*I, son inverse (X'X)^-1 est (1/8)*I.
# La formule devient : theta = (1/8) * X'Y
theta <- (t(X) %*% don$Y) / 8

cat("--- Estimation de tous les effets ---\n")
theta


# --- Première élimination (manuelle) ---
# En regardant la sortie ci-dessus, on repère l'effet le plus faible :
# L'effet 'AC' (valeur = -0.5) est le plus faible en valeur absolue.
# On le considère négligeable et on le retire du modèle.
# Le modèle n'est plus saturé.

# --- Analyse du modèle non saturé (AovSum) ---

cat("\n--- Analyse avec AovSum (sans 'AC') ---\n")

# On lance AovSum avec le modèle sans 'AC'
# Cette analyse va permettre d'obtenir le "modèle optimal final retenu"
# en estimant la significativité des effets restants.
resultat_aov <- AovSum(Y ~ A + B + C + D + AB + AD, data = don)

# On affiche le résumé (qui contient les deux tableaux)
resultat_aov


### Question 5 : Variances et Ecarts-Types
# --------------------------------------------------------------------------

# --- Lecture directe du tableau T.Test ---

# Extraire le tableau T test de l'objet AovSum
t_test_table <- resultat_aov$Ttest

# Extraire la colonne Std. Error (Écarts-Types)
# Grâce à l'orthogonalité du plan, Les écarts-types des coefficients estimés sont identiques (0.50)
# On vérifie ici cette propriété.
ecarts_types <- t_test_table[, "Std. Error"]

ecarts_types