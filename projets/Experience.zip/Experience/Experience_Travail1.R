################################
# Travail 1
################################

library(FrF2)

### Question 2.1 : Calcul des effets des différents facteurs et interaction
# --------------------------------------------------------------------------

# --- Construction du plan factoriel complet -----------------------

# Plan factoriel complet à 2 facteurs, 2 niveaux, non aléatoire
# Correspond au plan 2^2 = 4 essais
plan = FrF2(nruns = 4, nfactors = 2, randomize = FALSE)
plan

# --- Ajout des notes observées ------------------------------------

# Notes observées (dans l’ordre du plan)
# Ce sont les réponses "Y" du modèle 
y = c(34, 68, 54, 42)

# Combinaison plan + réponses
don = cbind.data.frame(plan, y)
don

# --- Calcul des moyennes par facteur ------------------------------

# Moyennes de Y pour chaque niveau du facteur A (Température)
moyA = tapply(don$y, don$A, mean)
moyA

# Moyennes de Y pour chaque niveau du facteur B (Temps)
moyB = tapply(don$y, don$B, mean)
moyB

# --- Calcul des effets globaux ------------------------------------

# Effet moyen global (mu)
# Correspond au terme μ dans le modèle Y = μ + αA + ... 
mu = mean(don$y)

# Effet du facteur A (Température)
# Formule de calcul de l'effet principal α, correspondant au terme αA du modèle 
alpha = 0.5 * (moyA["1"] - moyA["-1"])

# Effet du facteur B (Temps)
# Formule de calcul de l'effet principal β, correspondant au terme βB du modèle 
beta = 0.5 * (moyB["1"] - moyB["-1"])

# --- Calcul de l’interaction (A*B) --------------------------------

# Les colonnes A et B du plan sont de type "facteur" -> on les convertit en numériques
don$A_num <- as.numeric(as.character(don$A))
don$B_num <- as.numeric(as.character(don$B))

# Calcul du produit A*B (interaction)
don$AB <- don$A_num * don$B_num

# Moyennes par niveau d’interaction
moyAB = tapply(don$y, don$AB, mean)
moyAB

# Effet d’interaction (gamma)
# Formule de calcul de l'effet d'interaction γ, correspondant au terme γ(AB) du modèle 
gamma = 0.5 * (moyAB["1"] - moyAB["-1"])

# --- Résumé des résultats -----------------------------------------
cat("Résultats des effets\n")
cat("Effet moyen global (mu) =", mu, "\n")
cat("Effet de la température (A) =", alpha, "\n")
cat("Effet du temps (B) =", beta, "\n")
cat("Effet d’interaction (A*B) =", gamma, "\n")

# --- Vérification : valeurs estimées par le modèle ----------------
# Modèle : y = mu + alpha*A + beta*B + gamma*(A*B)
# Application directe du modèle estimé Y = μ + αA + βB + γ(AB) 
don$Y_estime = mu + alpha*don$A_num + beta*don$B_num + gamma*don$AB
don

# --- Visualisation graphique de l’interaction ---------------------
# (pour vérifier si interaction est présente)
interaction.plot(don$B, don$A, don$y,
                 type = "b",
                 col = c("red", "blue"),
                 pch = c(16, 17),
                 xlab = "Temps (facteur B)",
                 ylab = "Note moyenne",
                 trace.label = "Température (facteur A)",
                 main = "Graphique d’interaction : A x B")


### Question 2.2 : Écriture du modèle estimé
# ----------------------------------------------------------

# Affichage du modèle sous forme d'équation (valeurs codées)
# Formatage du modèle Y = μ + αA + βB + γ(AB)  avec les valeurs calculées
modele_estime <- sprintf("Y_estime = %.2f + %.2f*A - %.2f*B - %.2f*AB",
                         mu, alpha, abs(beta), abs(gamma))

cat("L'équation du modèle estimé est :\n")
modele_estime


### Question 2.3 : Tracer la surface de réponse
# ----------------------------------------------------------

# Définition des séquences de valeurs pour les facteurs codés
facteur_A_seq = seq(-1, 1, length = 20)
facteur_B_seq = seq(-1, 1, length = 20)

# Définition du modèle en variables codées
# Implémentation du modèle Y = μ + αA + βB + γ(AB)  sous forme de fonction
model_cookie = function(A, B) {
  mu + alpha*A + beta*B + gamma*A*B
}

# Calcul des valeurs estimées sur la grille (surface)
note_estimee_grid = outer(facteur_A_seq, facteur_B_seq, model_cookie)

# Tracé 3D de la surface de réponse
# Visualisation 3D du modèle Y = f(A, B)
persp(facteur_A_seq, facteur_B_seq, note_estimee_grid,
      ticktype = "detailed",
      theta = 20,
      col = "yellow",
      xlab = "Température (Facteur A)",
      ylab = "Temps (Facteur B)",
      zlab = "Note estimée (Y)",
      main = "Surface de réponse du modèle estimé")


### Question 2.4 : Tracer la courbe de niveaux
# ----------------------------------------------------------

# Définition du modèle en variables réelles (Température et Temps)
# C'est la forme "développée" du modèle Y = f(A,B), exprimée avec les variables non-codées
model2_cookie = function(temperature, temps) {
  -510 + 3.15*temperature + 51*temps - 0.2875*temperature*temps
}

# Séquences de valeurs réelles pour les variables
temp_seq = seq(160, 200, length = 30)
temps_seq = seq(8, 12, length = 30)

# Calcul de la note estimée sur la grille
note_estimee_grid_initiale = outer(temp_seq, temps_seq, model2_cookie)

# Tracé de la carte de contours (courbes de niveaux)
# Visualisation 2D du modèle Y = f(A, B)
contour(temp_seq, temps_seq, note_estimee_grid_initiale,
        xlab = "Température (°C)",
        ylab = "Temps (min)",
        col = "blue",
        nlevels = 20,
        lwd = 2,
        main = "Courbes de niveaux - Note estimée")



### Question 3.a : Température = 190°C et Temps = 10 min
# ----------------------------------------------------------

# Codage des valeurs
temp_a_initiale <- 190
temps_a_initial <- 10

# Formule de codage (X_codé = (X_réel - Centre) / (Demi-étendue))
# pour utiliser le modèle Y = μ + αA + βB + γ(AB) 
A_code <- (temp_a_initiale - 180) / 20
B_code <- (temps_a_initial - 10) / 2

# Prédiction
# Calcul de Y en utilisant le modèle  avec les valeurs codées A_code et B_code
note_predite_a <- mu + alpha * A_code + beta * B_code + gamma * (A_code * B_code)

cat("Note attendue (Y_estime) =", note_predite_a, "\n\n")


### Question 3.b Température = 185°C et Temps = 12 min
# ----------------------------------------------------------


cat("--- 3.b. Température = 185°C et Temps = 12 min ---\n")

# Codage des valeurs
temp_b_initiale <- 185
temps_b_initial <- 12

# Formule de codage pour A
A_code_b <- (temp_b_initiale - 180) / 20
# Formule de codage pour B
B_code_b <- (temps_b_initial - 10) / 2

# Prédiction
# Calcul de Y en utilisant le modèle 
note_predite_b <- mu + alpha * A_code_b + beta * B_code_b + gamma * (A_code_b * B_code_b)

cat("Note attendue (Y_estime) =", note_predite_b, "\n")



### Question 4-5 Combinaisons (Température, Temps) pour une note ≈ 50 et une note ≈ 60
# ------------------------------------------------------------------------------------

# Définition du modèle en variables réelles (non-codées)
# C'est le modèle Y = μ + αA + βB + γ(AB) 
# où A = (T - 180)/20 et B = (t - 10)/2
model_cookie_reel = function(T, t) {
  49.5 + 0.275 * (T - 180) - 0.75 * (t - 10) - 0.2875 * (T - 180) * (t - 10)
}

# --- 2. Création d'une grille de valeurs ------------------------------

# Température de 160°C à 200°C et Temps de cuisson de 8 à 12 minutes
temp_seq = seq(160, 200, by = 0.1) # pas de 0.1°C
temps_seq = seq(8, 12, by = 0.1) # pas de 0.1 min

# Création de la grille de toutes les combinaisons possibles
grille = expand.grid(T = temp_seq, t = temps_seq)

# Calcul de la note estimée pour chaque combinaison
# Application du modèle  en variables réelles
grille$Y_estime = with(grille, model_cookie_reel(T, t))


### --- Recherche des combinaisons proches de 50 --------------------
# Cette section utilise le modèle  pour trouver les entrées (T, t)
# qui donnent une sortie (Y) proche de 50

# Calcul de l’écart entre la note estimée et 50
grille$ecart_50 = abs(grille$Y_estime - 50)

# Tri des lignes selon l’écart croissant
grille_triee_50 = grille[order(grille$ecart_50), ]

# Sélection des 2 meilleures combinaisons
meilleures_50 = head(grille_triee_50, 2)

# Création du tableau récapitulatif
tableau_50 = data.frame(
  Température = meilleures_50$T,
  Temps_min = meilleures_50$t,
  Note_estimee = meilleures_50$Y_estime
)

# Affichage du tableau
cat("\nTableau des deux meilleures combinaisons pour une note ≈ 50 :\n")
print(tableau_50, row.names = FALSE)


### --- Recherche des combinaisons proches de 60 --------------------
# Même approche que ci-dessus, en utilisant le modèle  pour cibler Y ≈ 60

# Calcul de l’écart entre la note estimée et 60
grille$ecart_60 = abs(grille$Y_estime - 60)

# Tri des lignes selon l’écart croissant
grille_triee_60 = grille[order(grille$ecart_60), ]

# Sélection des 2 meilleures combinaisons
meilleures_60 = head(grille_triee_60, 2)

# Création du tableau récapitulatif
tableau_60 = data.frame(
  Température = meilleures_60$T,
  Temps_min = meilleures_60$t,
  Note_estimee = meilleures_60$Y_estime
)

# Affichage du tableau
cat("\nTableau des deux meilleures combinaisons pour une note ≈ 60 :\n")
print(tableau_60, row.names = FALSE)